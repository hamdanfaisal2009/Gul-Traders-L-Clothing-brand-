/* =========================================================
   NEARBY — service booking MVP
   Pure vanilla JS. Persistence via localStorage (survives refresh).
========================================================= */

// ---------- Storage keys ----------
const LS_KEYS = {
  users: 'nearby_users',
  providers: 'nearby_providers',
  bookings: 'nearby_bookings',
  reviews: 'nearby_reviews',
  session: 'nearby_session'
};

// ---------- Utilities ----------
function uid(prefix) {
  return prefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => toast.classList.add('hidden'), 2800);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function formatDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d)) return dateStr;
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

// ---------- Seed data (first run only) ----------
function seedProvidersIfEmpty() {
  let providers = load(LS_KEYS.providers, null);
  if (providers && providers.length) return providers;

  providers = [
    { id: uid('prov'), name: 'Aisha Karim', category: 'Plumbing', location: 'Gulshan-e-Iqbal, Karachi', experience: 7, price: 1500, rating: 4.8, reviewCount: 34, bio: 'Licensed plumber specializing in leak repair, fittings, and bathroom installations.' },
    { id: uid('prov'), name: 'Tariq Mehmood', category: 'Electrical', location: 'DHA Phase 5, Karachi', experience: 10, price: 2000, rating: 4.9, reviewCount: 51, bio: 'Certified electrician for wiring, fault-finding, and appliance installation.' },
    { id: uid('prov'), name: 'Sana Javed', category: 'House Cleaning', location: 'Clifton, Karachi', experience: 4, price: 1200, rating: 4.6, reviewCount: 22, bio: 'Deep-cleaning specialist for homes and small offices, eco-friendly products.' },
    { id: uid('prov'), name: 'Bilal Anwar', category: 'AC Repair', location: 'North Nazimabad, Karachi', experience: 9, price: 1800, rating: 4.7, reviewCount: 40, bio: 'HVAC technician for split-AC servicing, gas refill, and installation.' },
    { id: uid('prov'), name: 'Mariam Fahad', category: 'Tutoring', location: 'PECHS, Karachi', experience: 5, price: 1000, rating: 4.9, reviewCount: 18, bio: 'Math and Science tutor for grades 6–10, O-Level focused.' },
    { id: uid('prov'), name: 'Usman Raza', category: 'Carpentry', location: 'Malir, Karachi', experience: 12, price: 2200, rating: 4.5, reviewCount: 29, bio: 'Custom furniture, repairs, and cabinetry with a decade of workshop experience.' },
    { id: uid('prov'), name: 'Hina Yousuf', category: 'Painting', location: 'Bahadurabad, Karachi', experience: 6, price: 1600, rating: 4.7, reviewCount: 15, bio: 'Interior and exterior painting, texture work, and color consultation.' },
    { id: uid('prov'), name: 'Fahad Siddiqui', category: 'Appliance Repair', location: 'Nazimabad, Karachi', experience: 8, price: 1400, rating: 4.4, reviewCount: 26, bio: 'Washing machine, fridge, and microwave repair — same-day service.' }
  ];
  save(LS_KEYS.providers, providers);
  return providers;
}

// ---------- State ----------
let providers = [];
let bookings = [];
let reviews = [];
let users = [];
let session = null; // { userId, name, email, role }

// which action the auth modal is currently for: 'login' | 'register'
let authMode = 'login';
let selectedAuthRole = 'customer';

// remembers where booking form came from
let pendingBookingProviderId = null;

function init() {
  providers = seedProvidersIfEmpty();
  bookings = load(LS_KEYS.bookings, []);
  reviews = load(LS_KEYS.reviews, []);
  users = load(LS_KEYS.users, []);
  session = load(LS_KEYS.session, null);

  populateCategoryFilter();
  renderProviderGrid();
  updateAuthUI();
  bindGlobalEvents();
  navigate('home');
}

// ---------- Navigation ----------
function navigate(viewName) {
  // guard role-specific views
  if (viewName === 'customerDash' && (!session || session.role !== 'customer')) {
    openAuthModal('login');
    return;
  }
  if (viewName === 'providerDash' && (!session || session.role !== 'provider')) {
    openAuthModal('login');
    return;
  }

  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  const target = document.getElementById('view-' + viewName);
  if (target) target.classList.remove('hidden');

  if (viewName === 'customerDash') renderCustomerDashboard();
  if (viewName === 'providerDash') renderProviderDashboard();
  if (viewName === 'home') renderProviderGrid();

  document.getElementById('app').scrollIntoView({ behavior: 'smooth', block: 'start' });
  document.querySelector('.topbar').classList.remove('nav-open');
}

// ---------- Category filter ----------
function populateCategoryFilter() {
  const select = document.getElementById('categoryFilter');
  const categories = [...new Set(providers.map(p => p.category))].sort();
  categories.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    select.appendChild(opt);
  });
}

// ---------- Provider grid (home) ----------
function getFilteredProviders() {
  const query = document.getElementById('searchInput').value.trim().toLowerCase();
  const category = document.getElementById('categoryFilter').value;

  return providers.filter(p => {
    const matchesQuery = !query ||
      p.name.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query) ||
      p.location.toLowerCase().includes(query);
    const matchesCategory = !category || p.category === category;
    return matchesQuery && matchesCategory;
  });
}

function initials(name) {
  return name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

function renderProviderGrid() {
  const grid = document.getElementById('providerGrid');
  const list = getFilteredProviders();
  document.getElementById('resultCount').textContent =
    list.length + (list.length === 1 ? ' provider' : ' providers');

  if (!list.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <strong>No matches</strong>
      Try a different search term or clear the category filter.
    </div>`;
    return;
  }

  grid.innerHTML = list.map(p => `
    <article class="card">
      <div class="card-top">
        <div>
          <h3>${escapeHtml(p.name)}</h3>
          <span class="chip">${escapeHtml(p.category)}</span>
        </div>
        <div class="card-avatar">${escapeHtml(initials(p.name))}</div>
      </div>
      <p class="muted" style="margin:2px 0 0">${escapeHtml(p.location)}</p>
      <div class="card-meta">
        <span>${p.experience} yrs experience</span>
        <span class="rating">★ ${p.rating.toFixed(1)}</span>
      </div>
      <div class="card-actions">
        <button class="btn btn-outline" data-action="view-provider" data-id="${p.id}">View profile</button>
      </div>
    </article>
  `).join('');

  grid.querySelectorAll('[data-action="view-provider"]').forEach(btn => {
    btn.addEventListener('click', () => showProviderDetail(btn.dataset.id));
  });
}

// ---------- Provider detail ----------
function showProviderDetail(providerId) {
  const p = providers.find(x => x.id === providerId);
  if (!p) return;

  const detail = document.getElementById('providerDetail');
  detail.innerHTML = `
    <div class="detail-card">
      <div class="detail-avatar">${escapeHtml(initials(p.name))}</div>
      <div>
        <span class="chip">${escapeHtml(p.category)}</span>
        <h2>${escapeHtml(p.name)}</h2>
        <p class="muted" style="max-width:52ch">${escapeHtml(p.bio)}</p>
        <div class="detail-facts">
          <div class="fact"><span class="fact-label">location</span><span class="fact-value">${escapeHtml(p.location)}</span></div>
          <div class="fact"><span class="fact-label">experience</span><span class="fact-value">${p.experience} years</span></div>
          <div class="fact"><span class="fact-label">starting price</span><span class="fact-value">Rs ${p.price.toLocaleString()}</span></div>
          <div class="fact"><span class="fact-label">rating</span><span class="fact-value">★ ${p.rating.toFixed(1)} (${p.reviewCount} reviews)</span></div>
        </div>
      </div>
      <div>
        <button class="btn btn-solid" data-action="book" data-id="${p.id}">Request booking</button>
      </div>
    </div>
  `;

  detail.querySelector('[data-action="book"]').addEventListener('click', () => openBookingForm(p.id));
  navigate('provider');
}

// ---------- Booking form ----------
function openBookingForm(providerId) {
  if (!session || session.role !== 'customer') {
    pendingBookingProviderId = providerId;
    showToast('Log in as a customer to book this provider');
    openAuthModal('login', 'customer');
    return;
  }
  const p = providers.find(x => x.id === providerId);
  if (!p) return;

  pendingBookingProviderId = null;
  document.getElementById('bookingProviderId').value = p.id;
  document.getElementById('bookingProviderName').textContent = 'Book ' + p.name;
  document.getElementById('bookingForm').reset();
  document.getElementById('bookingProviderId').value = p.id; // reset() clears hidden too, re-set
  clearFormErrors('bookingForm');
  navigate('booking');
}

function clearFormErrors(formId) {
  document.querySelectorAll('#' + formId + ' .error').forEach(el => el.textContent = '');
}

function validateBookingForm() {
  let valid = true;
  const fields = [
    { id: 'bkService', message: 'Please describe the service needed.' },
    { id: 'bkDate', message: 'Please choose a date.' },
    { id: 'bkTime', message: 'Please choose a time.' },
    { id: 'bkLocation', message: 'Please add a location.' },
    { id: 'bkDescription', message: 'Please add a short description.' }
  ];

  fields.forEach(f => {
    const input = document.getElementById(f.id);
    const errorEl = document.querySelector(`.error[data-for="${f.id}"]`);
    const value = input.value.trim();
    if (!value) {
      errorEl.textContent = f.message;
      valid = false;
    } else {
      errorEl.textContent = '';
    }
  });

  // date cannot be in the past
  const dateInput = document.getElementById('bkDate');
  if (dateInput.value) {
    const chosen = new Date(dateInput.value + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (chosen < today) {
      document.querySelector('.error[data-for="bkDate"]').textContent = 'Date cannot be in the past.';
      valid = false;
    }
  }

  return valid;
}

function handleBookingSubmit(e) {
  e.preventDefault();
  if (!validateBookingForm()) return;

  const providerId = document.getElementById('bookingProviderId').value;
  const provider = providers.find(p => p.id === providerId);
  if (!provider) {
    showToast('Something went wrong — provider not found.');
    return;
  }

  const booking = {
    id: uid('bk'),                    // unique booking ID, business rule #1
    providerId: provider.id,
    providerName: provider.name,
    customerId: session.userId,
    customerName: session.name,
    service: document.getElementById('bkService').value.trim(),
    date: document.getElementById('bkDate').value,
    time: document.getElementById('bkTime').value,
    location: document.getElementById('bkLocation').value.trim(),
    description: document.getElementById('bkDescription').value.trim(),
    status: 'pending',
    createdAt: Date.now()
  };

  bookings.push(booking);
  save(LS_KEYS.bookings, bookings);
  showToast('Booking request sent to ' + provider.name);
  navigate('customerDash');
}

// ---------- Booking status state machine ----------
// Legal transitions only — enforces business rules 4 & 5
const ALLOWED_TRANSITIONS = {
  pending: ['accepted', 'rejected'],
  accepted: ['in_progress'],
  in_progress: ['completed'],
  rejected: [],
  completed: []
};

function transitionBooking(bookingId, newStatus) {
  const booking = bookings.find(b => b.id === bookingId);
  if (!booking) return false;

  const allowed = ALLOWED_TRANSITIONS[booking.status] || [];
  if (!allowed.includes(newStatus)) {
    showToast('That status change is not allowed.');
    return false;
  }

  booking.status = newStatus;
  booking.updatedAt = Date.now();
  save(LS_KEYS.bookings, bookings);
  return true;
}

// ---------- Customer dashboard ----------
function statusLabel(status) {
  return status.replace('_', ' ');
}

function renderCustomerDashboard() {
  const list = document.getElementById('customerBookingList');
  const mine = bookings
    .filter(b => b.customerId === session.userId)
    .sort((a, b) => b.createdAt - a.createdAt);

  if (!mine.length) {
    list.innerHTML = `<div class="empty-state">
      <strong>No bookings yet</strong>
      Browse providers and request your first booking.
    </div>`;
    return;
  }

  list.innerHTML = mine.map(b => {
    const review = reviews.find(r => r.bookingId === b.id);
    let actionHtml = '';

    if (b.status === 'completed' && !review) {
      actionHtml = `
        <div class="stars" data-booking="${b.id}">
          ${[1,2,3,4,5].map(n => `<button type="button" class="star-btn" data-value="${n}">★</button>`).join('')}
        </div>
        <button class="btn btn-solid" style="margin-top:6px" data-action="submit-review" data-id="${b.id}" disabled>Submit review</button>
      `;
    } else if (review) {
      actionHtml = `<div class="review-display"><span class="stars-inline">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</span> — your review</div>`;
    }

    return `
      <div class="booking-row">
        <div>
          <span class="booking-id">${b.id}</span>
        </div>
        <div class="booking-main">
          <h4>${escapeHtml(b.service)} with ${escapeHtml(b.providerName)}</h4>
          <div class="booking-sub">${formatDate(b.date)} at ${escapeHtml(b.time)} · ${escapeHtml(b.location)}</div>
          <div class="booking-desc">${escapeHtml(b.description)}</div>
          ${actionHtml}
        </div>
        <div class="booking-actions">
          <span class="status-badge status-${b.status}">${statusLabel(b.status)}</span>
        </div>
      </div>
    `;
  }).join('');

  // wire star selectors
  list.querySelectorAll('.stars').forEach(starsEl => {
    const bookingId = starsEl.dataset.booking;
    let selected = 0;
    const buttons = starsEl.querySelectorAll('.star-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        selected = parseInt(btn.dataset.value, 10);
        buttons.forEach(b => b.classList.toggle('filled', parseInt(b.dataset.value, 10) <= selected));
        const submitBtn = document.querySelector(`[data-action="submit-review"][data-id="${bookingId}"]`);
        submitBtn.disabled = false;
        submitBtn.dataset.rating = selected;
      });
    });
  });

  list.querySelectorAll('[data-action="submit-review"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const bookingId = btn.dataset.id;
      const rating = parseInt(btn.dataset.rating, 10);
      submitReview(bookingId, rating);
    });
  });
}

function submitReview(bookingId, rating) {
  const booking = bookings.find(b => b.id === bookingId);
  if (!booking) return;

  // Business rule: cannot review before completion
  if (booking.status !== 'completed') {
    showToast('This booking has not been completed yet.');
    return;
  }
  // Business rule: cannot submit more than one review per booking
  if (reviews.some(r => r.bookingId === bookingId)) {
    showToast('You already reviewed this booking.');
    return;
  }
  if (!rating || rating < 1 || rating > 5) {
    showToast('Please select a star rating.');
    return;
  }

  reviews.push({
    id: uid('rev'),
    bookingId,
    providerId: booking.providerId,
    customerId: booking.customerId,
    rating,
    createdAt: Date.now()
  });
  save(LS_KEYS.reviews, reviews);

  // update provider's aggregate rating
  recalculateProviderRating(booking.providerId);

  showToast('Thanks — your review was submitted.');
  renderCustomerDashboard();
}

function recalculateProviderRating(providerId) {
  const provider = providers.find(p => p.id === providerId);
  if (!provider) return;
  const providerReviews = reviews.filter(r => r.providerId === providerId);
  if (!providerReviews.length) return;
  const avg = providerReviews.reduce((sum, r) => sum + r.rating, 0) / providerReviews.length;
  provider.rating = Math.round(avg * 10) / 10;
  provider.reviewCount = providerReviews.length;
  save(LS_KEYS.providers, providers);
}

// ---------- Provider dashboard ----------
function renderProviderDashboard() {
  const list = document.getElementById('providerBookingList');
  // Match bookings to "this" provider account by matching provider name to session name.
  // (Simple MVP linkage: provider accounts are matched to a providers[] entry by name.)
  const myProviderRecord = providers.find(p => p.name.toLowerCase() === session.name.toLowerCase())
    || providers.find(p => p.linkedUserId === session.userId);

  const mine = bookings
    .filter(b => myProviderRecord ? b.providerId === myProviderRecord.id : b.providerId === session.providerId)
    .sort((a, b) => b.createdAt - a.createdAt);

  if (!mine.length) {
    list.innerHTML = `<div class="empty-state">
      <strong>No booking requests yet</strong>
      New requests from customers will show up here.
    </div>`;
    return;
  }

  list.innerHTML = mine.map(b => {
    let actions = '';
    if (b.status === 'pending') {
      actions = `
        <button class="btn btn-solid" data-action="accept" data-id="${b.id}">Accept</button>
        <button class="btn btn-outline" data-action="reject" data-id="${b.id}">Reject</button>
      `;
    } else if (b.status === 'accepted') {
      actions = `<button class="btn btn-solid" data-action="in_progress" data-id="${b.id}">Start work</button>`;
    } else if (b.status === 'in_progress') {
      actions = `<button class="btn btn-solid" data-action="completed" data-id="${b.id}">Mark completed</button>`;
    }

    return `
      <div class="booking-row">
        <div>
          <span class="booking-id">${b.id}</span>
        </div>
        <div class="booking-main">
          <h4>${escapeHtml(b.service)} — ${escapeHtml(b.customerName)}</h4>
          <div class="booking-sub">${formatDate(b.date)} at ${escapeHtml(b.time)} · ${escapeHtml(b.location)}</div>
          <div class="booking-desc">${escapeHtml(b.description)}</div>
        </div>
        <div class="booking-actions">
          <span class="status-badge status-${b.status}">${statusLabel(b.status)}</span>
          ${actions}
        </div>
      </div>
    `;
  }).join('');

  list.querySelectorAll('[data-action="accept"]').forEach(btn =>
    btn.addEventListener('click', () => { transitionBooking(btn.dataset.id, 'accepted'); renderProviderDashboard(); showToast('Booking accepted'); }));
  list.querySelectorAll('[data-action="reject"]').forEach(btn =>
    btn.addEventListener('click', () => { transitionBooking(btn.dataset.id, 'rejected'); renderProviderDashboard(); showToast('Booking rejected'); }));
  list.querySelectorAll('[data-action="in_progress"]').forEach(btn =>
    btn.addEventListener('click', () => { transitionBooking(btn.dataset.id, 'in_progress'); renderProviderDashboard(); showToast('Marked in progress'); }));
  list.querySelectorAll('[data-action="completed"]').forEach(btn =>
    btn.addEventListener('click', () => { transitionBooking(btn.dataset.id, 'completed'); renderProviderDashboard(); showToast('Marked completed'); }));
}

// ---------- Auth ----------
function openAuthModal(mode, presetRole) {
  authMode = mode;
  selectedAuthRole = presetRole || 'customer';
  const modal = document.getElementById('authModal');
  const isLogin = mode === 'login';

  document.getElementById('authKicker').textContent = isLogin ? 'Welcome back' : 'Join Nearby';
  document.getElementById('authTitle').textContent = isLogin ? 'Log in' : 'Create your account';
  document.getElementById('authSubmit').textContent = isLogin ? 'Log in' : 'Create account';
  document.getElementById('authNameField').classList.toggle('hidden', isLogin);
  document.getElementById('authRoleField').classList.toggle('hidden', isLogin);
  document.getElementById('authSwitchText').textContent = isLogin ? 'New to Nearby?' : 'Already have an account?';
  document.getElementById('authSwitchBtn').textContent = isLogin ? 'Sign up' : 'Log in';

  document.querySelectorAll('.role-btn').forEach(b => b.classList.toggle('active', b.dataset.roleVal === selectedAuthRole));

  document.getElementById('authForm').reset();
  clearFormErrors('authForm');
  modal.classList.remove('hidden');
}

function closeAuthModal() {
  document.getElementById('authModal').classList.add('hidden');
}

function validateAuthForm(isLogin) {
  let valid = true;
  if (!isLogin) {
    const name = document.getElementById('authName').value.trim();
    const errorEl = document.querySelector('.error[data-for="authName"]');
    if (!name) { errorEl.textContent = 'Please enter your name.'; valid = false; }
    else errorEl.textContent = '';
  }
  const email = document.getElementById('authEmail').value.trim();
  const emailError = document.querySelector('.error[data-for="authEmail"]');
  if (!email || !email.includes('@')) { emailError.textContent = 'Please enter a valid email.'; valid = false; }
  else emailError.textContent = '';

  const password = document.getElementById('authPassword').value;
  const passError = document.querySelector('.error[data-for="authPassword"]');
  if (!password || password.length < 4) { passError.textContent = 'Password must be at least 4 characters.'; valid = false; }
  else passError.textContent = '';

  return valid;
}

function handleAuthSubmit(e) {
  e.preventDefault();
  const isLogin = authMode === 'login';
  if (!validateAuthForm(isLogin)) return;

  const email = document.getElementById('authEmail').value.trim().toLowerCase();
  const password = document.getElementById('authPassword').value;

  if (isLogin) {
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) {
      document.querySelector('.error[data-for="authPassword"]').textContent = 'Incorrect email or password.';
      return;
    }
    session = { userId: user.id, name: user.name, email: user.email, role: user.role };
  } else {
    const name = document.getElementById('authName').value.trim();
    if (users.some(u => u.email === email)) {
      document.querySelector('.error[data-for="authEmail"]').textContent = 'An account with this email already exists.';
      return;
    }
    const newUser = { id: uid('user'), name, email, password, role: selectedAuthRole };
    users.push(newUser);
    save(LS_KEYS.users, users);

    // If registering as a provider, auto-create a linked provider listing if one doesn't exist by name.
    if (selectedAuthRole === 'provider' && !providers.some(p => p.name.toLowerCase() === name.toLowerCase())) {
      providers.push({
        id: uid('prov'),
        name,
        category: 'General Services',
        location: 'Not set',
        experience: 0,
        price: 0,
        rating: 5.0,
        reviewCount: 0,
        bio: 'New provider on Nearby.',
        linkedUserId: newUser.id
      });
      save(LS_KEYS.providers, providers);
      populateCategoryFilterRefresh();
    }

    session = { userId: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role };
  }

  save(LS_KEYS.session, session);
  updateAuthUI();
  closeAuthModal();
  showToast('Welcome, ' + session.name + '!');

  if (session.role === 'customer' && pendingBookingProviderId) {
    openBookingForm(pendingBookingProviderId);
  } else if (session.role === 'customer') {
    navigate('customerDash');
  } else {
    navigate('providerDash');
  }
}

function populateCategoryFilterRefresh() {
  const select = document.getElementById('categoryFilter');
  const current = select.value;
  select.innerHTML = '<option value="">All categories</option>';
  const categories = [...new Set(providers.map(p => p.category))].sort();
  categories.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    select.appendChild(opt);
  });
  select.value = current;
}

function logout() {
  session = null;
  localStorage.removeItem(LS_KEYS.session);
  updateAuthUI();
  navigate('home');
  showToast('Logged out');
}

function updateAuthUI() {
  const whoami = document.getElementById('whoami');
  const btnLogout = document.getElementById('btnLogout');
  const btnLogin = document.getElementById('btnLogin');
  const btnRegister = document.getElementById('btnRegister');

  if (session) {
    whoami.textContent = session.name + ' · ' + session.role;
    whoami.classList.remove('hidden');
    btnLogout.classList.remove('hidden');
    btnLogin.classList.add('hidden');
    btnRegister.classList.add('hidden');
  } else {
    whoami.classList.add('hidden');
    btnLogout.classList.add('hidden');
    btnLogin.classList.remove('hidden');
    btnRegister.classList.remove('hidden');
  }

  document.querySelectorAll('[data-role]').forEach(el => {
    const requiredRole = el.dataset.role;
    el.style.display = (session && session.role === requiredRole) ? '' : 'none';
  });
}

// ---------- Global events ----------
function bindGlobalEvents() {
  document.querySelectorAll('[data-nav]').forEach(el => {
    el.addEventListener('click', () => navigate(el.dataset.nav));
  });

  document.getElementById('searchInput').addEventListener('input', renderProviderGrid);
  document.getElementById('categoryFilter').addEventListener('change', renderProviderGrid);

  document.getElementById('bookingForm').addEventListener('submit', handleBookingSubmit);

  document.getElementById('btnLogin').addEventListener('click', () => openAuthModal('login'));
  document.getElementById('btnRegister').addEventListener('click', () => openAuthModal('register'));
  document.getElementById('btnLogout').addEventListener('click', logout);
  document.getElementById('authModalClose').addEventListener('click', closeAuthModal);
  document.getElementById('authModal').addEventListener('click', (e) => {
    if (e.target.id === 'authModal') closeAuthModal();
  });
  document.getElementById('authForm').addEventListener('submit', handleAuthSubmit);
  document.getElementById('authSwitchBtn').addEventListener('click', () => {
    openAuthModal(authMode === 'login' ? 'register' : 'login');
  });
  document.querySelectorAll('.role-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedAuthRole = btn.dataset.roleVal;
      document.querySelectorAll('.role-btn').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  document.getElementById('hamburger').addEventListener('click', () => {
    document.querySelector('.topbar').classList.toggle('nav-open');
  });
}

// ---------- Boot ----------
document.addEventListener('DOMContentLoaded', init);
